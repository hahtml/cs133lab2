export PATH=/usr/local/cs/bin:$PATH
export PATH=/usr/local/cs133/openmpi-install/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cs133/openmpi-install/lib:$PATH
