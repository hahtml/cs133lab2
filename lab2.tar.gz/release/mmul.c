#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

// Please modify this function

void mmul(float *A, float *B, float *C, int n)
{


}

